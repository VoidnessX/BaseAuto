#-*- coding: utf-8 -*-
import os, sys
import urllib
import re 
from bs4 import BeautifulSoup as bs 
from selenium import webdriver
import selenium


# for unicode setting
reload(sys)
sys.setdefaultencoding('utf-8')

url = "http://sports.news.naver.com/gameCenter/gameRecord.nhn?category=kbo&gameId=20150307HTNC0"

# basic html crawling function 
def get_page(url):
    return urllib.urlopen(url).read()

'''
soup = bs(get_page(url), 'html.parser')
res = soup.find_all("div", {"class" : "inner"})
for elem in res:
    print elem.text
	
print len(res)
'''

browser = webdriver.Chrome()
browser.get(url)
while True:
	try:
		table_lst = browser.find_elements_by_class_name("t_result_board2")
		for table in table_lst:
			print table.text
		print len(table_lst)
		break
	except selenium.common.exceptions.NoSuchElementException:
		pass
		
#browser.quit()
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		