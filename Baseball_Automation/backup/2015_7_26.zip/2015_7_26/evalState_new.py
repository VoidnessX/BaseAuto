# without player change, team change, exceptional cases, ... 
# if there is offense team change, following code seems to be valid
def evalState(event, before):
	# no change in players.
	offense_before = before.offense_team
	offense_after = event.offense_result.evalOffenseTeam(offense_before)
	defense_after = before.defense_team
	
	# should be handled in case of more than 3 out.
	out_after = event.offense_result.evalOutCnt() + before.out 
	# if more than 3 out, change
	if out_after >= 3:
		return teamChange(event, before) # need more info here
	# if outcount is less than 3, game goes on without teamchange.
	
	# this function is for no change in strike/ball/turn
	strike_after = before.strike
	turn_after = before.turn
	is_home_after = before.is_home
	ball_after = before.ball
	
	# score eval : divide case - if home is offense/away is offense
	score_after = before.score
	
	if before.is_home = True: # if home is offense, increase home score
		score_after[0] += event.offense_result.evalScore()
	else: # if away is offense, increase away score
		score_after[1] += event.offense_result.evalScore() 
	
	
	return State(offense_after.getPlayerLst(), 
				 defense_after.getPlayerLst(),
				 ball_after, 
				 out_after, 
				 strike_after, 
				 turn_after, 
				 score_after, 
				 is_home_after)
	
'''
in case of strike/ball/..., just change the state strike/ball/... 
'''
