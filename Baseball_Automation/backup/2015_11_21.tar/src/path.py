#-*- coding: utf-8 -*-
import os, sys

# RAW_ARTICLE_DIR : directory for saving raw articles
global RAW_ARTICLE_PATH = "../raw/articles/"
# TEXTREL_DIR : directory for saving text relays
global RAW_TXT_PATH = "../raw/texts/"

