#-*- coding: utf-8 -*-
import os, sys, re
import datetime

from eventClass import Team
from playerData import Player, PLAYER_LIST

# for unicode setting
reload(sys)
sys.setdefaultencoding('utf-8')

# test constructPlayerList in Team 
nexen = Team(u"넥센", ["nexen", "nex"], 0, "mokdong")
nexen.constructPlayerList()

print nexen.player_lst


