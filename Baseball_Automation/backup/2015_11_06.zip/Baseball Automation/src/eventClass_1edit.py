#-*- coding: utf-8 -*-
import os, sys, re
import datetime

# for unicode setting
reload(sys)
sys.setdefaultencoding('utf-8')


class Player():
	def __init__(self): 
		self.name = None 
		self.career = []
		self.birthday = None
		self.position = None
		self.id_number = -1 
		self.salary = None
		
	def updateCareer(self):
		pass
		

		
		
		
class Team():
	def __init__(self, official_name, names, number, playerList, home): 
		self.official_name = official_name
		self.names = names
		self.number = number
		self.playerList = playerList
		self.record = ""
		self.homeGround = home
		
		
		
class OffenseTeam():
	def __init__(self):
		self.position = {"hitter" : None, "b1runner" : None, "b2runner" : None, "b3runner" : None} 
		self.is_home = True
	
	def setPosition(self, player_lst):
		self.position["hitter"] = player_lst[0]
		self.position["b1runner"] = player_lst[1]
		self.position["b2runner"] = player_lst[2]
		self.position["b3runner"] = player_lst[3]
	
	def setTeam(self, bool):
		self.is_home = bool
	

class DefenseTeam():
	def __init__(self):
		position_lst = ["pitcher", "catcher", "b1man", "b2man",  "b3man", "shotstop", "leftfielder", "centerfielder", "rightfielder"]
		self.position = {}
		for elem in position_lst: 
			self.position.update({elem : None})
		self.is_home = True
		
	def setPosition(self, playerLst):
		# need better implementation 
		self.position["pitcher"] = player_lst[0]
		self.position["catcher"] = player_lst[1]
		self.position["b1man"] = player_lst[2]
		self.position["b2man"] = player_lst[3]
		self.position["b3man"] = player_lst[4]
		self.position["shotstop"] = player_lst[5]
		self.position["leftfielder"] = player_lst[6]
		self.position["centerfielder"] = player_lst[7]
		self.position["rightfielder"] = player_lst[8]
		
	def setTeam(self, bool):
		self.isHome = bool
	

class State():
	def __init__(self):
		'''
		offense_team_position : class OffenseTeam
		offense_team_position : class DefenseTeam
		xx_cnt : xx count 
		is_home : if True, home team is offense. 
		'''
		self.offense_team_position = OffenseTeam()
		self.defense_team_position = DefenseTeam()
		self.ball_cnt = 0
		self.out_cnt = 0
		self.strike_cnt = 0
		self.turn_cnt = 0
		self.is_home = True
		
	def setState(self, offense_lst, defense_lst, ball, out, strike, turn, bool):
		self.offense_team_position.setPosition(offense_lst)
		self.defense_team_position.setPosition(defense_lst)
		self.ball_cnt = ball
		self.out_cnt = out
		self.strike_cnt = strike
		self.turn_cnt = turn
		self.is_home = bool
	
	
class Event():
	def __init__(self, before, after, event_name, hitter, b1runner, b2runner, b3runner):
		"""
		before : state before event 
		after : state after event
		"""
		self.hitter = hitter
		self.before = before
		self.after = after
		self.event_name = event_name

	def getHitter(self):
		return self.hitter
	
	def getB1runner(self):
		return self.b1runner
	
	def getB2runner(self):
		return self.b2runner

	def getB3runner(self):
		return self.b3runner
			
	
class Hitted(Event):
	def __init__(self):
		pass
		
class Game():
	def __init__(self):
		pass
		

class fair(hitted):
	def __init__(self):
		pass

class foul(hitted):
	def __init__(self):
		pass

class hit(fair):
	def __init__(self):
		pass

class hit(fair):
	def __init__(self):
		pass

class single(hit):
	def __init__(self):
		pass

class double(hit):
	def __init__(self):
		pass

class triple(hit):
	def __init__(self):
		pass

class homerun(hit):
	def __init__(self):
		pass

class error(hit):

