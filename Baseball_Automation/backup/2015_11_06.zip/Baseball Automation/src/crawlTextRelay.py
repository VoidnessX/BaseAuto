#-*- coding: utf-8 -*-
from selenium import webdriver
from bs4 import BeautifulSoup as bs 
import urllib
import os, sys


# for unicode setting
reload(sys)
sys.setdefaultencoding('utf-8')


# basic html crawling function 
def get_page(url):
    return urllib.urlopen(url).read()
	
	
def getUrlList(month):
	# need to be extended to more urls 
	source_url = "http://sports.news.naver.com/schedule/index.nhn?uCategory=&category=kbo&year=2015&month=%s"%month
	
	soup = bs(get_page(source_url), 'html.parser')
	
	tmp = soup.find_all('div', {'class' , 'sch_tb', 'sch_tb2'})
	
	gameIdLst = []

	for elem in tmp:
		for link in elem.find_all('a', href=True):
			gameIdLst.append(link['href'].split('=')[-1])
			
	gameIdLst = list(set(gameIdLst))
	
	return gameIdLst


def textRelayCrawler(gameIdLst, path):	

	browser = webdriver.Chrome()
	for id in gameIdLst:
	
		newText = True
		try:
			state = open("..\\raw\\texts\\current_data.txt", "r")
			for line in state.readlines():
				if line.strip() == id:
					newText = False
			state.close()
		except IOError:
			open('..\\raw\\texts\\current_data.txt','w+').close()


		if newText:			
			date = id[:8]	
			if not os.path.exists("%s\\%s"%(path, date)):
				os.makedirs("%s%s"%(path, date))
			text = open("%s%s\\%s"%(path, date, id + ".txt"), "w+")
			
		
			date = id[:8]
			url = 'http://sports.news.naver.com/gameCenter/miniTextRelay.nhn?category=kbo&date=%s&gameId=%s'%(date, id)
		
			print "parsing from %s"%url
		
			browser.get(url)
			button = browser.find_element_by_id('inning_tab_all')
			button.click()
			#Get Relay_Text
			relay_text = browser.find_element_by_id('relay_text')
			text.write(relay_text.text)
			text.close()
			
			state = open("..\\raw\\texts\\current_data.txt", "a+")
			state.write(id + "\n")
			state.close()
			#print relay_text.text
		
		else:
			pass
	brower.quit()
	

if __name__ == "__main__":

	TEXTREL_DIR = "..\\raw\\texts\\"
	if not os.path.exists(TEXTREL_DIR):
		os.makedirs(TEXTREL_DIR)
	gameLst = []

	for i in range(3, 10):
		gameLst.extend(getUrlList(str(i)))
		
	textRelayCrawler(gameLst, TEXTREL_DIR)
	
	
